#!/bin/bash
set -e

# Navigate to driver source directory
cd "$(dirname "$0")"

echo "Applying configuration changes in os/linux/config.mk..."
sed -i 's/^HAS_WPA_SUPPLICANT *=.*$/HAS_WPA_SUPPLICANT=y/' os/linux/config.mk
sed -i 's/^HAS_NATIVE_WPA_SUPPLICANT_SUPPORT *=.*$/HAS_NATIVE_WPA_SUPPLICANT_SUPPORT=y/' os/linux/config.mk
sed -i 's/^#*HAS_USB_SUPPORT *=.*$/HAS_USB_SUPPORT=y/' os/linux/config.mk

echo "Patching cfg80211.c for SME_SUPPORT range..."
patch -p1 << 'EOF'
*** Begin Patch
*** Update File: os/linux/cfg80211/cfg80211.c
@@ -137,7 +137,9 @@
-#if (LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,33))
+#if (LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,33)) && (LINUX_VERSION_CODE < KERNEL_VERSION(5,8,0))
  cfg80211_ops.sme = rtcfg_sme;
#endif
*** End Patch
EOF

echo "Updating net_device_ops initialization in rt_main_dev.c..."
patch -p1 << 'EOF'
*** Begin Patch
*** Update File: os/linux/rt_main_dev.c
@@ -250,7 +250,7 @@
-    dev->priv = ...;  // legacy
+    /* Use netdev_priv() for private data */
+    priv = netdev_priv(dev);
*** End Patch
EOF

echo "Fixing priv usage instances..."
sed -i 's/\(->\)priv/\1priv = netdev_priv(dev)/g' os/linux/rt_main_dev.c || true

echo "Patching dma address casting in rtmp_pkt.c (if exists)..."
if [ -f os/linux/rtmp_pkt.c ]; then
  patch -p1 << 'EOF'
*** Begin Patch
*** Update File: os/linux/rtmp_pkt.c
@@ -102,7 +102,7 @@
-    cpPacket->pBuffer = (PUCHAR)__va(dma_addr);
+    cpPacket->pBuffer = phys_to_virt(dma_addr);
*** End Patch
EOF
fi

echo "Stubbing deprecated ioctl handlers in rt_linux.c..."
patch -p1 << 'EOF'
*** Begin Patch
*** Update File: os/linux/rt_linux.c
@@ -400,7 +400,7 @@
-    // legacy wireless handlers...
+    // Stubbed deprecated wireless handlers for compatibility
*** End Patch
EOF

echo "Building the driver..."
make -C os/linux -j$(nproc)

echo "Installing the module..."
sudo make -C os/linux install

echo "Loading the mt7612u_sta module..."
sudo modprobe mt7612u_sta || sudo modprobe mt7612u

echo "Build and installation complete. You can now configure your interface."
